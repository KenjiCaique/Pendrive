function tabuada(){
var numero = parseFloat(prompt('Digite um numero'));
var i = 0;

while (i <= 10){
    console.log(numero + "x" + i + "=" + numero * i);
    i++;
}
}
tabuada();