var pais = parseFloat(prompt('Digite o seu pais: '));
if(pais == 'brasil'){
    alert('Você é brasileiro');
}else{
    alert('Você não é estrangeiro');
}
