var velocidade = parseFloat(prompt('Digite sua velocidade: '));
if(velocidade > 60){
    alert('Você ultrapassou o limite permitido');
}else{
    alert('Você está dentro do limite permitido');
}